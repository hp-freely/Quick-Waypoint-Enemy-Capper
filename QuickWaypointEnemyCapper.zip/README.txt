////
// The purpose of this script is to provide a keybind that quickly allows the script user to waypoint the most recent enemy player which grabbed 
// the flag off of your flagstand. The script uses T2's built-in "AttackPlayer" task (as opposed to using the "createWaypoint()" function used by
// scripts like BuddyPoints). This means that one and only one waypoint can be created at any time. It also means that this waypoint will be removed
// if the user accepts *any other* task. 
//
// In other words, it's the exact same functionality as a) right-clicking an enemy player via the command map, b) selecting "Attack" via the menu option, 
// and then c) using the quickchat menu to accept that task (using VCA). All of these actions are shortcutted into a single keybind.
//
// The goal is to support quick enemy capper waypointing with at least some restrictions. If one were to use the "createWaypoint()" function, then that action
// essentially bypasses the way T2 intended players to waypoint enemies.
//
// Beyond all of the above, the following additional points are important to know:
// a) The script will only waypoint the most recent enemy player to grabbed your flag off the flag stand. If a player has not yet grabbed the flag, then no waypoint
//    can be created. If a player grabs the flag in the field, then a waypoint will *not* be created for that player.
// b) The purposeful goal is to help defense map one and only one capper from the enemy team. Ideally, a person would waypoint the capper they feel is most dangerous.
// c) Given that this uses T2's built-in task system, the capper waypoint will be cleared / removed according to the exact same logic that T2 uses to clear / remove tasks.
//    This applies for switching teams, leaving a match, matches ending, and loading a new match.
////

--Known Bug--
By default, T2 does not make most keybinds available to the player when they are piloting a vehicle (or in the bomber position). I feel that, given the purpose of this
script, not having being able to use it while piloting is an unacceptable limitation. If found a way to make the keybind work for players when they are piloting. However,
there is a side effect that the command to create the waypoint gets called *twice*.

I cannot find a way to prevent this / work around this. The side effect is that, when you're piloting, you will here the "waypoint added" sound twice. It will have a
stero effect, which is a bit offputting.

--Dependencies--
None

--Instructions--
1. Move QuickWaypointEnemyCapper.vl2 to your z_scripts or scripts folder
	